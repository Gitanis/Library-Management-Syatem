const Library = artifacts.require("Library");

contract("Library", (accounts) => {
  let libraryInstance;

  before(async () => {
    libraryInstance = await Library.deployed();
  });

  it("should add 10 default books upon deployment", async () => {
    const bookCount = await libraryInstance.bookCount();
    assert.equal(bookCount.toNumber(), 10, "Initial book count should be 10");
  });

  it("should have correct details for the first default book", async () => {
    const book = await libraryInstance.books(1);
    assert.equal(book.title, "Book 1", "First book should have title 'Book 1'");
    assert.equal(book.author, "Author 1", "First book should have author 'Author 1'");
    assert.equal(book.isAvailable, true, "First book should be available");
  });

  it("should allow a user to borrow a book", async () => {
    await libraryInstance.borrowBook(1, { from: accounts[0] });
    const book = await libraryInstance.books(1);
    assert.equal(book.isAvailable, false, "Book should be borrowed and unavailable");
    assert.equal(book.borrower, accounts[0], "Borrower should be the first account");
  });

  it("should allow a user to return a book", async () => {
    await libraryInstance.returnBook(1, { from: accounts[0] });
    const book = await libraryInstance.books(1);
    assert.equal(book.isAvailable, true, "Book should be returned and available");
    assert.equal(book.borrower, "0x0000000000000000000000000000000000000000", "Borrower should be reset");
  });

  it("should allow an admin to add a new book", async () => {
    await libraryInstance.addBook("New Book", "New Author", { from: accounts[0] });
    const bookCount = await libraryInstance.bookCount();
    const newBook = await libraryInstance.books(bookCount);
    assert.equal(newBook.title, "New Book", "New book should have title 'New Book'");
    assert.equal(newBook.author, "New Author", "New book should have author 'New Author'");
  });
});
