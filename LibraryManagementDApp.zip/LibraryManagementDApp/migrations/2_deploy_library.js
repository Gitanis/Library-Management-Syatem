const Library = artifacts.require("Library");

module.exports = async function (deployer) {
  await deployer.deploy(Library);
  const library = await Library.deployed();

  const defaultBooks = [
    { title: "Book 1", author: "Author 1" },
    { title: "Book 2", author: "Author 2" },
    { title: "Book 3", author: "Author 3" },
    { title: "Book 4", author: "Author 4" },
    { title: "Book 5", author: "Author 5" },
    { title: "Book 6", author: "Author 6" },
    { title: "Book 7", author: "Author 7" },
    { title: "Book 8", author: "Author 8" },
    { title: "Book 9", author: "Author 9" },
    { title: "Book 10", author: "Author 10" }
  ];

  for (const book of defaultBooks) {
    await library.addBook(book.title, book.author);
  }
};
