// src/App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import getWeb3 from './utils/web3';
import getLibraryContract from './utils/LibraryContract';
import NavBar from './components/NavBar';
import Home from './pages/Home';
import Books from './pages/Books';
import Admin from './pages/Admin';

const App = () => {
  const [web3, setWeb3] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [contract, setContract] = useState(null);

  useEffect(() => {
    const init = async () => {
      const web3 = await getWeb3();
      const accounts = await web3.eth.getAccounts();
      const contract = await getLibraryContract(web3);
      setWeb3(web3);
      setAccounts(accounts);
      setContract(contract);
    };
    init();
  }, []);

  return (
    <Router>
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/books" element={<Books contract={contract} accounts={accounts} />} />
        <Route path="/admin" element={<Admin contract={contract} accounts={accounts} />} />
      </Routes>
    </Router>
  );
};

export default App;
