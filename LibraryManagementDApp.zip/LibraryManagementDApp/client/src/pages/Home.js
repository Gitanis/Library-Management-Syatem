// src/pages/Home.js
import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
  card: {
    backgroundColor: theme.palette.background.paper,
    marginTop: theme.spacing(4),
    padding: theme.spacing(2),
  },
}));

const Home = () => {
  const classes = useStyles();

  return (
    <Container>
      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h4" gutterBottom>
            Welcome to the Library Management System
          </Typography>
          <Typography variant="body1">
            Manage your library seamlessly with our DApp. Navigate to the Books page to view and borrow books, or to the Admin page to manage the library.
          </Typography>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Home;