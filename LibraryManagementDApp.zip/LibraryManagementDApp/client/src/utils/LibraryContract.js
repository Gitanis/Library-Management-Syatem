import Library from './Library.json';

const getLibraryContract = async (web3) => {
  const networkId = await web3.eth.net.getId();
  const deployedNetwork = Library.networks[networkId];
  const instance = new web3.eth.Contract(Library.abi, deployedNetwork && deployedNetwork.address);
  return instance;
};

export default getLibraryContract;