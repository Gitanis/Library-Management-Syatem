// src/pages/Admin.js
import React, { useState } from 'react';
import Container from '@mui/material/Container';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
  card: {
    backgroundColor: theme.palette.background.paper,
    marginTop: theme.spacing(4),
    padding: theme.spacing(2),
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
  button: {
    color: theme.palette.primary.main,
  },
}));

const Admin = ({ contract, accounts }) => {
  const classes = useStyles();
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    await contract.methods.addBook(title, author).send({ from: accounts[0] });
    setTitle('');
    setAuthor('');
  };

  return (
    <Container>
      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h4" gutterBottom>
            Admin Panel
          </Typography>
          <form className={classes.form} onSubmit={handleSubmit}>
            <TextField
              label="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              fullWidth
              color="secondary"
            />
            <TextField
              label="Author"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              fullWidth
              color="secondary"
            />
            <Button type="submit" variant="contained" className={classes.button}>
              Add Book
            </Button>
          </form>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Admin;