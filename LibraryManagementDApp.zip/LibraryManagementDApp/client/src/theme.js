import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#ffffff', // White color
    },
    secondary: {
      main: '#000000', // Black color
    },
    background: {
      default: '#000000', // Black background
      paper: '#000000', // Black paper
    },
    text: {
      primary: '#ffffff', // White text
      secondary: '#ffffff', // White text
    },
  },
  typography: {
    fontFamily: 'Roboto, sans-serif',
    h4: {
      color: '#ffffff', // White color for headers
    },
    body1: {
      color: '#ffffff', // White color for body text
    },
  },
});

export default theme;