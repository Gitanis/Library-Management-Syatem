// src/components/NavBar.js
import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';
import { makeStyles } from '@mui/styles';
import logo from '../assets/logo.png';

const useStyles = makeStyles((theme) => ({
  logo: {
    height: 40,
    marginRight: theme.spacing(2),
  },
  navLink: {
    color: theme.palette.primary.main,
    textDecoration: 'none',
    marginRight: theme.spacing(2),
  },
}));

const NavBar = () => {
  const classes = useStyles();

  return (
    <AppBar position="static" color="primary">
      <Toolbar>
        <img src={logo} alt="Logo" className={classes.logo} />
        <Typography variant="h6" style={{ flexGrow: 1 }}>
          Library Management System
        </Typography>
        <Button className={classes.navLink} component={Link} to="/">
          Home
        </Button>
        <Button className={classes.navLink} component={Link} to="/books">
          Books
        </Button>
        <Button className={classes.navLink} component={Link} to="/admin">
          Admin
        </Button>
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
