// src/pages/Books.js
import React, { useState, useEffect } from 'react';
import Container from '@mui/material/Container';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
  card: {
    backgroundColor: theme.palette.background.paper,
    marginTop: theme.spacing(4),
    padding: theme.spacing(2),
  },
  cardContent: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  button: {
    color: theme.palette.primary.main,
  },
}));

const Books = ({ contract, accounts }) => {
  const classes = useStyles();
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const fetchBooks = async () => {
      const bookCount = await contract.methods.bookCount().call();
      const booksArray = [];
      for (let i = 1; i <= bookCount; i++) {
        const book = await contract.methods.books(i).call();
        booksArray.push(book);
      }
      setBooks(booksArray);
    };

    if (contract) {
      fetchBooks();
    }
  }, [contract]);

  const handleBorrow = async (id) => {
    await contract.methods.borrowBook(id).send({ from: accounts[0] });
    window.location.reload();
  };

  const handleReturn = async (id) => {
    await contract.methods.returnBook(id).send({ from: accounts[0] });
    window.location.reload();
  };

  return (
    <Container>
      {books.map((book) => (
        <Card key={book.id} className={classes.card}>
          <CardContent className={classes.cardContent}>
            <Typography variant="h5">{book.title}</Typography>
            <Typography variant="body2">Author: {book.author}</Typography>
          </CardContent>
          <CardActions>
            <Button
              onClick={() => handleBorrow(book.id)}
              disabled={!book.isAvailable}
              className={classes.button}
            >
              {book.isAvailable ? 'Borrow' : 'Unavailable'}
            </Button>
            <Button
              onClick={() => handleReturn(book.id)}
              disabled={book.isAvailable}
              className={classes.button}
            >
              Return
            </Button>
          </CardActions>
        </Card>
      ))}
    </Container>
  );
};

export default Books;